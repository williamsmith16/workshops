# 🚀 Setup Guide — Deymoon Platformer Starter

The project code and scenes are all pre-wired. You just need to get the
sprite PNGs into Godot. Follow these steps exactly.

---

## Step 1 — Load the Project

1. Go to https://editor.godotengine.org
2. Drag **deymoon-platformer.zip** onto the Project Manager window
3. Click **Install & Edit**

---

## Step 2 — Add the Sprite Files

The sprites must be dragged in directly — do NOT use the ZIP for this.

1. Open your **Deymoon character pack folder** on your computer (included in the package)
2. In Godot, find the **FileSystem panel** (bottom left)
3. Right-click `sprites/player/` → **Create Folder** if it doesn't exist
4. Drag ALL 13 PNGs from your Deymoon folder into `sprites/player/`:

```
character_air-spin.png
character_crouch-idle.png
character_crouch-walk.png
character_idle.png  (may be named character_idle-.png)
character_jump.png
character_land.png
character_ledge-climb.png
character_ledge-grab.png
character_roll.png
character_run.png
character_walk.png
character_wall-land.png
character_wall-slide.png
```

Godot will auto-import them when you drop them in.

---

## Step 3 — Wire Up Each Animation

1. In the Scene panel, click **Player** → **AnimatedSprite2D**
2. In the Inspector, click **SpriteFrames** to open the animation panel
3. For each animation in the list, click it then click **"Add frames from sprite sheet"**
4. Navigate to `sprites/player/` and select the matching PNG
5. Set **Columns** per the table below, **Rows = 1**, then select all frames

| Animation    | PNG file                  | Columns |
|-------------|---------------------------|---------|
| idle         | character_idle.png        | 6       |
| walk         | character_walk.png        | 8       |
| run          | character_run.png         | 8       |
| roll         | character_roll.png        | 11      |
| jump         | character_jump.png        | 4       |
| air_spin     | character_air-spin.png    | 8       |
| land         | character_land.png        | 3       |
| crouch_idle  | character_crouch-idle.png | 4       |
| crouch_walk  | character_crouch-walk.png | 11      |
| ledge_climb  | character_ledge-climb.png | 5       |
| ledge_grab   | character_ledge-grab.png  | 1       |
| wall_slide   | character_wall-slide.png  | 2       |
| wall_land    | character_wall-land.png   | 1       |

---

## Step 4 — Set Texture Filter (Critical!)

Project Settings → Rendering → Textures → **Default Texture Filter → Nearest**

Without this, sprites look blurry.

---

## Controls

| Key            | Action                  |
|----------------|-------------------------|
| A / ←          | Move left               |
| D / →          | Move right              |
| Space / ↑      | Jump                    |
| Space (in air) | Double jump (air spin)  |
| S / ↓          | Crouch                  |
| Shift          | Roll                    |
| Jump into wall | Wall slide              |
